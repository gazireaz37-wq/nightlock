package com.reaz.nightlock

import android.app.AppOpsManager
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

object Perm {
    @Suppress("DEPRECATION")
    fun usageAccess(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }
}

data class Night(val key: String, var att: Int, var em: Int)

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    // ---- ডিফল্ট সময় (মিনিট; রাত ১২:৩০ = 30, সকাল ৬:০০ = 360) ----
    fun start(c: Context) = sp(c).getInt("start", 30)
    fun end(c: Context) = sp(c).getInt("end", 360)

    // ---- দিনভেদে আলাদা সময় (0 = রবি ... 6 = শনি) ----
    fun startFor(c: Context, dow: Int) = sp(c).getInt("s_$dow", start(c))
    fun endFor(c: Context, dow: Int) = sp(c).getInt("e_$dow", end(c))

    // কোন কোন রাতে লক (বিট 0 = রবি ... বিট 6 = শনি)
    fun days(c: Context) = sp(c).getInt("days", 127)

    // ---- ২৪ ঘণ্টার নিয়ম ----
    // লক চালু থাকলে, লক দুর্বল করে এমন বদল ২৪ ঘণ্টা পরে কার্যকর হয়।
    // লক শক্ত করে এমন বদল (বেশি সময়, বেশি দিন, কম অ্যাপ) সঙ্গে সঙ্গে কার্যকর হয়।
    @Volatile private var noticePending = false

    fun takePendingNotice(): Boolean {
        val v = noticePending
        noticePending = false
        return v
    }

    private fun winLen(s: Int, e: Int) = if (s <= e) e - s else 1440 - s + e

    private fun clearPend(ed: android.content.SharedPreferences.Editor, key: String) {
        ed.remove("p_$key")
        ed.remove("pt_$key")
    }

    private fun queue(c: Context, key: String, value: String) {
        sp(c).edit()
            .putString("p_$key", value)
            .putLong("pt_$key", System.currentTimeMillis() + DISABLE_WAIT_MIN * 60_000L)
            .apply()
        noticePending = true
    }

    private fun commitInt(c: Context, key: String, v: Int, stronger: Boolean) {
        if (!enabled(c) || stronger) {
            val ed = sp(c).edit()
            ed.putInt(key, v)
            clearPend(ed, key)
            ed.apply()
        } else queue(c, key, "i:$v")
    }

    private fun commitBool(c: Context, key: String, v: Boolean, stronger: Boolean) {
        if (!enabled(c) || stronger) {
            val ed = sp(c).edit()
            ed.putBoolean(key, v)
            clearPend(ed, key)
            ed.apply()
        } else queue(c, key, "b:" + (if (v) "1" else "0"))
    }

    private fun commitSet(c: Context, key: String, v: Set<String>, stronger: Boolean) {
        if (!enabled(c) || stronger) {
            val ed = sp(c).edit()
            ed.putStringSet(key, HashSet(v))
            clearPend(ed, key)
            ed.apply()
        } else queue(c, key, "a:" + v.joinToString(","))
    }

    private fun commitRemove(c: Context, key: String, stronger: Boolean) {
        if (!enabled(c) || stronger) {
            val ed = sp(c).edit()
            ed.remove(key)
            clearPend(ed, key)
            ed.apply()
        } else queue(c, key, "r")
    }

    fun setDays(c: Context, v: Int) {
        val old = days(c)
        commitInt(c, "days", v, (v and old) == old)
    }

    fun setStart(c: Context, v: Int) {
        val e = end(c)
        commitInt(c, "start", v, winLen(v, e) >= winLen(start(c), e))
    }

    fun setEnd(c: Context, v: Int) {
        val s = start(c)
        commitInt(c, "end", v, winLen(s, v) >= winLen(s, end(c)))
    }

    fun setDaySchedule(c: Context, dow: Int, s: Int, e: Int) {
        val st = winLen(s, e) >= winLen(startFor(c, dow), endFor(c, dow))
        commitInt(c, "s_$dow", s, st)
        commitInt(c, "e_$dow", e, st)
    }

    fun clearDaySchedules(c: Context) {
        for (i in 0..6) {
            if (!sp(c).contains("s_$i") && !sp(c).contains("e_$i")) continue
            val st = winLen(start(c), end(c)) >= winLen(startFor(c, i), endFor(c, i))
            commitRemove(c, "s_$i", st)
            commitRemove(c, "e_$i", st)
        }
    }

    fun setJitter(c: Context, v: Int) = commitInt(c, "jitter", v, v <= jitterMax(c))

    fun setAllowed(c: Context, s: Set<String>) = commitSet(c, "allow", s, allowed(c).containsAll(s))

    fun setModeOn(c: Context, i: Int, v: Boolean) = commitBool(c, "m${i}_on", v, v)

    fun setModeDays(c: Context, i: Int, v: Int) {
        val old = modeDays(c, i)
        commitInt(c, "m${i}_days", v, (v and old) == old)
    }

    fun setModeStart(c: Context, i: Int, v: Int) {
        val e = modeEnd(c, i)
        commitInt(c, "m${i}_s", v, winLen(v, e) >= winLen(modeStart(c, i), e))
    }

    fun setModeEnd(c: Context, i: Int, v: Int) {
        val s = modeStart(c, i)
        commitInt(c, "m${i}_e", v, winLen(s, v) >= winLen(s, modeEnd(c, i)))
    }

    fun setModeAllowed(c: Context, i: Int, s: Set<String>) =
        commitSet(c, "m${i}_allow", s, modeAllowed(c, i).containsAll(s))

    /** সময় পার হওয়া অপেক্ষমাণ বদলগুলো কার্যকর করে; কিছু বদলালে true */
    fun applyPendingChanges(c: Context): Boolean {
        val s = sp(c)
        val now = System.currentTimeMillis()
        val due = s.all.keys.filter { it.startsWith("pt_") && s.getLong(it, Long.MAX_VALUE) <= now }
        if (due.isEmpty()) return false
        val ed = s.edit()
        for (pk in due) {
            val key = pk.substring(3)
            val v = s.getString("p_$key", null)
            if (v != null) {
                if (v.startsWith("i:")) {
                    val n = v.substring(2).toIntOrNull()
                    if (n != null) ed.putInt(key, n)
                } else if (v.startsWith("b:")) {
                    ed.putBoolean(key, v.substring(2) == "1")
                } else if (v.startsWith("a:")) {
                    ed.putStringSet(key, v.substring(2).split(",").filter { it.isNotEmpty() }.toHashSet())
                } else if (v == "r") {
                    ed.remove(key)
                }
            }
            clearPend(ed, key)
        }
        ed.apply()
        return true
    }

    fun pendingCount(c: Context): Int = sp(c).all.keys.count { it.startsWith("pt_") }

    fun cancelPendingChanges(c: Context) {
        val s = sp(c)
        val ed = s.edit()
        for (k in s.all.keys.toList()) {
            if (k.startsWith("p_") || k.startsWith("pt_")) ed.remove(k)
        }
        ed.apply()
    }

    private val DAY_SHORT = arrayOf("রবি", "সোম", "মঙ্গল", "বুধ", "বৃহস্পতি", "শুক্র", "শনি")

    private fun daysMaskText(m: Int): String {
        if (m == 127) return "প্রতি দিন"
        if (m == 0) return "কোনো দিন নয়"
        return (0..6).filter { (m and (1 shl it)) != 0 }.joinToString(", ") { DAY_SHORT[it] }
    }

    private fun keyLabel(key: String): String {
        val m = Regex("^m(\\d)_(.+)$").find(key)
        if (m != null) {
            val i = m.groupValues[1].toInt()
            val what = when (m.groupValues[2]) {
                "on" -> "চালু/বন্ধ"
                "days" -> "দিন"
                "s" -> "শুরু"
                "e" -> "শেষ"
                "allow" -> "অনুমোদিত অ্যাপ"
                else -> m.groupValues[2]
            }
            return MODE_NAMES[i] + " মোড: " + what
        }
        val d = Regex("^([se])_(\\d)$").find(key)
        if (d != null) {
            return DAY_SHORT[d.groupValues[2].toInt()] + ": " + (if (d.groupValues[1] == "s") "শুরু" else "শেষ")
        }
        return when (key) {
            "days" -> "ঘুম মোড: রাতের দিন"
            "start" -> "ঘুম মোড: ডিফল্ট শুরু"
            "end" -> "ঘুম মোড: ডিফল্ট শেষ"
            "jitter" -> "ঘুম মোড: এলোমেলো দেরি"
            "allow" -> "ঘুম মোড: অনুমোদিত অ্যাপ"
            else -> key
        }
    }

    private fun valueText(key: String, v: String): String {
        if (v == "r") return "ডিফল্টে ফেরা"
        val body = v.substring(2)
        return when {
            v.startsWith("a:") -> "${body.split(",").filter { it.isNotEmpty() }.size}টি অ্যাপ"
            v.startsWith("b:") -> if (body == "1") "চালু" else "বন্ধ"
            key == "days" || key.endsWith("_days") -> daysMaskText(body.toIntOrNull() ?: 0)
            key == "jitter" -> "$body মিনিট"
            else -> fmt(body.toIntOrNull() ?: 0)
        }
    }

    fun pendingLines(c: Context): List<String> {
        val s = sp(c)
        val now = System.currentTimeMillis()
        val out = ArrayList<Pair<Long, String>>()
        for (pk in s.all.keys.filter { it.startsWith("pt_") }) {
            val key = pk.substring(3)
            val v = s.getString("p_$key", null) ?: continue
            val left = maxOf(0L, s.getLong(pk, now) - now) / 60000
            out.add(Pair(left, "• " + keyLabel(key) + " → " + valueText(key, v) + " (" + humanDuration(left.toInt()) + " পরে)"))
        }
        return out.sortedBy { it.first }.map { it.second }
    }

    // ---- বন্ধ করার অপেক্ষা ----
    const val DISABLE_WAIT_MIN = 24 * 60

    private fun disableAt(c: Context) = sp(c).getLong("disableAt", 0L)

    fun requestDisable(c: Context) =
        sp(c).edit().putLong("disableAt", System.currentTimeMillis() + DISABLE_WAIT_MIN * 60_000L).apply()

    fun cancelDisable(c: Context) = sp(c).edit().remove("disableAt").apply()

    /** বন্ধ করার অনুরোধ থাকলে বাকি মিনিট, নাহলে null */
    fun disableMinutesLeft(c: Context): Int? {
        val t = disableAt(c)
        if (t == 0L) return null
        return maxOf(0, ((t - System.currentTimeMillis()) / 60000).toInt())
    }

    /** অপেক্ষার সময় শেষ হলে লক বন্ধ করে দেয়; বন্ধ হলে true */
    fun applyPendingDisable(c: Context): Boolean {
        val t = disableAt(c)
        if (t == 0L || System.currentTimeMillis() < t) return false
        setEnabled(c, false)
        sp(c).edit().remove("disableAt").apply()
        // লক বন্ধ হলে অ্যাপে ঢোকার পথ যেন থাকে
        setStealth(c, false)
        Stealth.setIconVisible(c, true)
        return true
    }

    // ---- অন্যান্য মোড (0 = পড়াশোনা, 1 = কাজ) ----
    val MODE_ICONS = arrayOf("📚", "💼")
    private val MODE_NAMES = arrayOf("পড়াশোনা", "কাজ")
    private val MODE_START = intArrayOf(9 * 60, 10 * 60)
    private val MODE_END = intArrayOf(12 * 60, 17 * 60)

    fun modeName(i: Int) = MODE_NAMES[i]
    fun modeOn(c: Context, i: Int) = sp(c).getBoolean("m${i}_on", false)
    fun modeDays(c: Context, i: Int) = sp(c).getInt("m${i}_days", 127)
    fun modeStart(c: Context, i: Int) = sp(c).getInt("m${i}_s", MODE_START[i])
    fun modeEnd(c: Context, i: Int) = sp(c).getInt("m${i}_e", MODE_END[i])
    fun modeMsg(c: Context, i: Int) = sp(c).getString("m${i}_msg", "ফোকাস সময়") ?: "ফোকাস সময়"
    fun setModeMsg(c: Context, i: Int, v: String) = sp(c).edit().putString("m${i}_msg", v).apply()
    fun modeAllowed(c: Context, i: Int): Set<String> =
        HashSet(sp(c).getStringSet("m${i}_allow", emptySet()) ?: emptySet())

    private fun modeActive(c: Context, i: Int): Boolean {
        if (!enabled(c) || !modeOn(c, i)) return false
        val now = Calendar.getInstance()
        val m = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val s = modeStart(c, i)
        val e = modeEnd(c, i)
        val inTime = if (s <= e) m in s until e else (m >= s || m < e)
        if (!inTime) return false
        val d = now.clone() as Calendar
        if (s > e && m < e) d.add(Calendar.DAY_OF_YEAR, -1)
        val dow = d.get(Calendar.DAY_OF_WEEK) - 1
        return (modeDays(c, i) and (1 shl dow)) != 0
    }

    fun activeExtraMode(c: Context): Int? {
        for (i in 0..1) if (modeActive(c, i)) return i
        return null
    }

    fun activeMsg(c: Context): String {
        val m = activeExtraMode(c)
        return if (inLockWindow(c) || m == null) msg(c) else modeMsg(c, m)
    }

    fun activeEnd(c: Context): Int {
        val m = activeExtraMode(c)
        return if (inLockWindow(c) || m == null) currentEnd(c) else modeEnd(c, m)
    }

    fun activeAllowed(c: Context): Set<String> {
        val m = activeExtraMode(c)
        return if (inLockWindow(c) || m == null) allowed(c) else modeAllowed(c, m)
    }

    fun activeIcon(c: Context): String {
        val m = activeExtraMode(c)
        return if (inLockWindow(c) || m == null) "🌙" else MODE_ICONS[m]
    }

    // ---- লক পর্দার বার্তা ----
    fun msg(c: Context) = sp(c).getString("msg", "এখন ঘুমের সময়") ?: "এখন ঘুমের সময়"
    fun setMsg(c: Context, v: String) = sp(c).edit().putString("msg", v).apply()

    // ---- গোপন মোড ও এলোমেলো দেরি ----
    fun stealth(c: Context) = sp(c).getBoolean("stealth", false)
    fun setStealth(c: Context, v: Boolean) = sp(c).edit().putBoolean("stealth", v).apply()

    fun jitterMax(c: Context) = sp(c).getInt("jitter", 0)

    /** প্রতি রাতের জন্য গোপনে ঠিক করা এলোমেলো দেরি (মিনিট) */
    private fun jitterFor(c: Context): Int {
        val j = jitterMax(c)
        if (j <= 0) return 0
        var salt = sp(c).getString("jsalt", null)
        if (salt == null) {
            salt = UUID.randomUUID().toString()
            sp(c).edit().putString("jsalt", salt).apply()
        }
        return ((nightKey() + salt).hashCode() and 0x7fffffff) % (j + 1)
    }

    // ---- লক সময়ে অনুমোদিত অ্যাপ ----
    fun allowed(c: Context): Set<String> = HashSet(sp(c).getStringSet("allow", emptySet()) ?: emptySet())

    // ---- পাসওয়ার্ড ----
    private fun hash(s: String) =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    fun hasPass(c: Context) = sp(c).contains("hash")
    fun setPass(c: Context, p: String) {
        val salt = UUID.randomUUID().toString()
        sp(c).edit().putString("salt", salt).putString("hash", hash(salt + p)).apply()
    }
    fun checkPass(c: Context, p: String): Boolean {
        val salt = sp(c).getString("salt", "") ?: ""
        return hash(salt + p) == sp(c).getString("hash", "")
    }

    // ---- রাত কোন দিনের ----
    // দুপুরের আগের সময় আগের দিনের রাত হিসেবে ধরা হয়
    // (যেমন শুক্রবার = শুক্রবার সন্ধ্যা থেকে শনিবার ভোর)
    private fun nightCal(cal: Calendar): Calendar {
        val c = cal.clone() as Calendar
        if (c.get(Calendar.HOUR_OF_DAY) < 12) c.add(Calendar.DAY_OF_YEAR, -1)
        return c
    }

    private fun nightKey(): String {
        val n = nightCal(Calendar.getInstance())
        return "%04d-%02d-%02d".format(n.get(Calendar.YEAR), n.get(Calendar.MONTH) + 1, n.get(Calendar.DAY_OF_MONTH))
    }

    /** এই রাতের লক শেষের সময় (মিনিট) */
    fun currentEnd(c: Context): Int =
        endFor(c, nightCal(Calendar.getInstance()).get(Calendar.DAY_OF_WEEK) - 1)

    // ---- লক সময় ----
    fun inLockWindow(c: Context): Boolean {
        if (!enabled(c)) return false
        val now = Calendar.getInstance()
        val m = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val d = nightCal(now).get(Calendar.DAY_OF_WEEK) - 1
        val s0 = startFor(c, d)
        val e = endFor(c, d)
        val j = jitterFor(c)
        val s = if (s0 <= e) minOf(s0 + j, maxOf(s0, e - 1)) else (s0 + j) % 1440
        val inTime = if (s <= e) m in s until e else (m >= s || m < e)
        return inTime && (days(c) and (1 shl d)) != 0
    }

    fun shouldLock(c: Context) = inLockWindow(c) || activeExtraMode(c) != null

    /** লক শুরুর আগের ১–১৫ মিনিটে বাকি মিনিট, নাহলে null */
    fun minutesToLock(c: Context): Int? {
        if (!enabled(c)) return null
        val now = Calendar.getInstance()
        now.set(Calendar.SECOND, 0)
        now.set(Calendar.MILLISECOND, 0)
        for (off in -1..1) {
            val d = now.clone() as Calendar
            d.add(Calendar.DAY_OF_YEAR, off)
            val dow = d.get(Calendar.DAY_OF_WEEK) - 1
            if ((days(c) and (1 shl dow)) == 0) continue
            val s = startFor(c, dow)
            val st = d.clone() as Calendar
            if (s < 720) st.add(Calendar.DAY_OF_YEAR, 1)
            st.set(Calendar.HOUR_OF_DAY, s / 60)
            st.set(Calendar.MINUTE, s % 60)
            val diff = ((st.timeInMillis - now.timeInMillis) / 60000).toInt()
            if (diff in 1..15) return diff
        }
        return null
    }

    // ---- রাতের রেকর্ড ----
    private fun loadNights(c: Context): MutableList<Night> {
        val raw = sp(c).getString("nights", "") ?: ""
        if (raw.isEmpty()) return mutableListOf()
        return raw.split(";").mapNotNull { p ->
            val f = p.split(":")
            if (f.size == 3) Night(f[0], f[1].toIntOrNull() ?: 0, f[2].toIntOrNull() ?: 0) else null
        }.toMutableList()
    }

    private fun saveNights(c: Context, l: List<Night>) {
        val t = if (l.size > 60) l.takeLast(60) else l
        sp(c).edit().putString("nights", t.joinToString(";") { "${it.key}:${it.att}:${it.em}" }).apply()
    }

    private fun night(l: MutableList<Night>): Night {
        val k = nightKey()
        val found = l.firstOrNull { it.key == k }
        if (found != null) return found
        val n = Night(k, 0, 0)
        l.add(n)
        return n
    }

    fun touchNight(c: Context) {
        val l = loadNights(c)
        val before = l.size
        night(l)
        if (l.size != before) saveNights(c, l)
    }

    fun addAttempt(c: Context) {
        val l = loadNights(c)
        night(l).att++
        saveNights(c, l)
    }

    private fun finishedNights(c: Context): List<Night> {
        val l = loadNights(c)
        val k = nightKey()
        return if (inLockWindow(c)) l.filter { it.key != k } else l
    }

    /** টানা কত রাত ফোন খোলার চেষ্টা ছাড়া কেটেছে */
    fun streak(c: Context): Int {
        var n = 0
        for (x in finishedNights(c).asReversed()) {
            if (x.att == 0) n++ else break
        }
        return n
    }

    fun recentNights(c: Context): List<Night> = loadNights(c).takeLast(7).reversed()

    // ---- স্ট্যাটাস (উইজেট ও টাইলের জন্য) ----
    /** পরের লক শুরুর আগে কত মিনিট বাকি (ডিফল্ট/দিনভেদে সময় অনুযায়ী) */
    fun minutesToNextLock(c: Context): Int? {
        val now = Calendar.getInstance()
        now.set(Calendar.SECOND, 0)
        now.set(Calendar.MILLISECOND, 0)
        var best: Int? = null
        for (off in -1..8) {
            val d = now.clone() as Calendar
            d.add(Calendar.DAY_OF_YEAR, off)
            val dow = d.get(Calendar.DAY_OF_WEEK) - 1
            if ((days(c) and (1 shl dow)) == 0) continue
            val s = startFor(c, dow)
            val st = d.clone() as Calendar
            if (s < 720) st.add(Calendar.DAY_OF_YEAR, 1)
            st.set(Calendar.HOUR_OF_DAY, s / 60)
            st.set(Calendar.MINUTE, s % 60)
            val diff = ((st.timeInMillis - now.timeInMillis) / 60000).toInt()
            val b = best
            if (diff > 0 && (b == null || diff < b)) best = diff
        }
        return best
    }

    fun humanDuration(min: Int): String {
        val d = min / 1440
        val h = (min % 1440) / 60
        val m = min % 60
        val sb = StringBuilder()
        if (d > 0) sb.append("$d দিন ")
        if (h > 0) sb.append("$h ঘণ্টা ")
        if (m > 0 || (d == 0 && h == 0)) sb.append("$m মিনিট")
        return sb.toString().trim()
    }

    fun shortStatus(c: Context): String {
        if (!enabled(c)) return "বন্ধ আছে"
        if (shouldLock(c)) return "এখন লক চলছে"
        val m = minutesToNextLock(c) ?: return "কোনো রাত বাছা নেই"
        return "লক হতে ${humanDuration(m)}"
    }

    fun fmt(min: Int): String {
        val h24 = min / 60
        val m = min % 60
        val ampm = if (h24 < 12) "AM" else "PM"
        val h = if (h24 % 12 == 0) 12 else h24 % 12
        return "%d:%02d %s".format(h, m, ampm)
    }
}

object Stealth {
    private const val ALIAS = "com.reaz.nightlock.LauncherAlias"

    fun setIconVisible(c: Context, visible: Boolean) {
        c.packageManager.setComponentEnabledSetting(
            ComponentName(c.packageName, ALIAS),
            if (visible) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
    }
}
