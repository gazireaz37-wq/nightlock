package com.reaz.floatingtext

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView

class FloatingTextService : Service() {

    private lateinit var wm: WindowManager
    private var tv: TextView? = null
    private lateinit var lp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var dx = 4
    private var dy = 4
    private var moving = true

    private val tick = object : Runnable {
        override fun run() {
            val v = tv ?: return
            val dm = resources.displayMetrics
            val maxX = (dm.widthPixels - v.width).coerceAtLeast(0)
            val maxY = (dm.heightPixels - v.height).coerceAtLeast(0)
            lp.x += dx
            lp.y += dy
            if (lp.x <= 0) { lp.x = 0; dx = -dx }
            if (lp.x >= maxX) { lp.x = maxX; dx = -dx }
            if (lp.y <= 0) { lp.y = 0; dy = -dy }
            if (lp.y >= maxY) { lp.y = maxY; dy = -dy }
            try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
            handler.postDelayed(this, 16)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()

        val prefs = getSharedPreferences("ft", MODE_PRIVATE)
        moving = prefs.getBoolean("move", true)

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val density = resources.displayMetrics.density
        val pad = (8 * density).toInt()

        tv = TextView(this).apply {
            text = prefs.getString("text", "")
            textSize = prefs.getInt("size", 20).toFloat()
            setTextColor(Color.WHITE)
            setShadowLayer(6f, 0f, 0f, Color.BLACK)
            setBackgroundColor(Color.argb(110, 0, 0, 0))
            setPadding(pad, pad / 2, pad, pad / 2)
        }

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50
            y = 300
        }

        wm.addView(tv, lp)
        if (moving) handler.postDelayed(tick, 500)
    }

    private fun startAsForeground() {
        val chId = "floating_text"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(chId, "Floating Text", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, chId)
            .setContentTitle("ফ্লোটিং টেক্সট চালু আছে")
            .setContentText("বন্ধ করতে অ্যাপ খুলুন")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        tv?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        tv = null
        super.onDestroy()
    }
}
