package com.reaz.nightlock

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class LockActivity : Activity() {

    private var leaveOk = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float, color: String, bold: Boolean, bottom: Int): TextView =
        TextView(this).apply {
            text = t
            textSize = size
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor(color))
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(bottom))
        }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#0B1020")
        window.navigationBarColor = Color.parseColor("#0B1020")

        val icon = Prefs.activeIcon(this)
        val msg = Prefs.activeMsg(this)
        val endText = Prefs.fmt(Prefs.activeEnd(this))
        val allowed = Prefs.activeAllowed(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(32), dp(96), dp(32), dp(32))
            setBackgroundColor(Color.parseColor("#0B1020"))
        }
        root.addView(label(icon, 72f, "#FFFFFF", false, 16))
        root.addView(label(msg, 28f, "#FFFFFF", true, 8))
        root.addView(label("ফোন $endText পর্যন্ত লক থাকবে", 16f, "#94A3B8", false, 40))

        if (allowed.isNotEmpty() && Perm.usageAccess(this)) {
            root.addView(label("অনুমোদিত অ্যাপ", 14f, "#94A3B8", false, 8))
            for (pkg in allowed) {
                val launch = packageManager.getLaunchIntentForPackage(pkg) ?: continue
                val name = try {
                    packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
                } catch (e: Exception) { pkg }
                val btn = Button(this)
                btn.text = name
                btn.isAllCaps = false
                btn.textSize = 16f
                btn.setTextColor(Color.WHITE)
                btn.stateListAnimator = null
                btn.background = GradientDrawable().apply {
                    setColor(Color.parseColor("#334155"))
                    cornerRadius = dp(14).toFloat()
                }
                btn.setOnClickListener {
                    startService(Intent(this, LockService::class.java).putExtra("watch", pkg))
                    leaveOk = true
                    startActivity(launch)
                    finish()
                }
                root.addView(btn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            }
        }

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0B1020"))
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        shown = true
    }

    // এই পর্দা ছেড়ে গেলেই আবার লক
    override fun onPause() {
        super.onPause()
        shown = false
        if (!leaveOk && Prefs.shouldLock(this)) LockService.lockNow(this)
    }

    companion object {
        @Volatile var shown = false
    }
}
