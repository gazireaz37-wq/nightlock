package com.reaz.floatingtext

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    private lateinit var input: EditText
    private lateinit var moveSwitch: Switch
    private lateinit var sizeBar: SeekBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("ft", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "স্ক্রিনে ভাসমান লেখা"
            textSize = 22f
            gravity = Gravity.CENTER
        })

        input = EditText(this).apply {
            hint = "এখানে আপনার লেখা লিখুন"
            setText(prefs.getString("text", "বিসমিল্লাহ কম্পিউটার জোন"))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        root.addView(input)

        moveSwitch = Switch(this).apply {
            text = "লেখা স্ক্রিনে ঘুরবে"
            isChecked = prefs.getBoolean("move", true)
        }
        root.addView(moveSwitch)

        root.addView(TextView(this).apply { text = "লেখার সাইজ" })
        sizeBar = SeekBar(this).apply {
            max = 40
            progress = prefs.getInt("size", 20) - 10
        }
        root.addView(sizeBar)

        root.addView(Button(this).apply {
            text = "চালু করুন"
            setOnClickListener { start() }
        })
        root.addView(Button(this).apply {
            text = "বন্ধ করুন"
            setOnClickListener { stopService(Intent(this@MainActivity, FloatingTextService::class.java)) }
        })

        setContentView(ScrollView(this).apply { addView(root) })

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "\"Display over other apps\" পারমিশন দিন", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        getSharedPreferences("ft", MODE_PRIVATE).edit()
            .putString("text", input.text.toString())
            .putBoolean("move", moveSwitch.isChecked)
            .putInt("size", sizeBar.progress + 10)
            .apply()
        stopService(Intent(this, FloatingTextService::class.java))
        startForegroundService(Intent(this, FloatingTextService::class.java))
        Toast.makeText(this, "চালু হয়েছে", Toast.LENGTH_SHORT).show()
    }
}
