package com.reaz.nightlock

import android.app.admin.DeviceAdminReceiver

class AdminReceiver : DeviceAdminReceiver()
