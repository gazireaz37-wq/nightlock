NightLock (রাতের লক)
1. Android Studio (Koala বা নতুন) এ এই ফোল্ডার Open করুন।
2. Gradle Sync শেষ হলে: Build > Build Bundle(s)/APK(s) > Build APK(s)
3. app/build/outputs/apk/debug/app-debug.apk ফোনে পাঠিয়ে ইনস্টল করুন।
