package com.reaz.nightlock

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "এটি বন্ধ করলে রাতে ফোন আর লক হবে না। আপনি কি নিশ্চিত?"
}
