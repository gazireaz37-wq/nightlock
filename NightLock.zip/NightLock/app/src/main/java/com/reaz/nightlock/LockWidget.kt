package com.reaz.nightlock

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class LockWidget : AppWidgetProvider() {

    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, build(c))
    }

    companion object {
        fun build(c: Context): RemoteViews {
            val v = RemoteViews(c.packageName, R.layout.widget)
            val stealth = Prefs.stealth(c)
            v.setTextViewText(R.id.w_title, if (stealth) "ব্যাকগ্রাউন্ড" else "🔒 রাতের লক")
            v.setTextViewText(R.id.w_status, Prefs.shortStatus(c))
            v.setTextViewText(
                R.id.w_sub,
                if (Prefs.enabled(c)) "টানা পরিষ্কার রাত: ${Prefs.streak(c)}" else "ট্যাপ করে সেটআপ করুন"
            )
            val pi = PendingIntent.getActivity(
                c, 0, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            v.setOnClickPendingIntent(R.id.w_root, pi)
            return v
        }

        fun updateAll(c: Context) {
            try {
                val m = AppWidgetManager.getInstance(c)
                val ids = m.getAppWidgetIds(ComponentName(c, LockWidget::class.java))
                for (id in ids) m.updateAppWidget(id, build(c))
            } catch (_: Exception) {
            }
        }
    }
}
