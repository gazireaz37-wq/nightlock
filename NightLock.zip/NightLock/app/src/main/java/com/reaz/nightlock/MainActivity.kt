package com.reaz.nightlock

import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var btnAdmin: Button
    private lateinit var btnStart: Button
    private lateinit var btnEnd: Button
    private lateinit var btnToggle: Button

    private val admin by lazy { ComponentName(this, AdminReceiver::class.java) }
    private val dpm by lazy { getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        fun btn(): Button = Button(this).apply {
            textSize = 17f
            root.addView(this, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 24 })
        }

        root.addView(TextView(this).apply {
            text = "🔒 রাতের লক"
            textSize = 28f
            gravity = Gravity.CENTER
        })
        status = TextView(this).apply { textSize = 17f; setPadding(0, 32, 0, 16) }
        root.addView(status)

        btnAdmin = btn().also { it.setOnClickListener { requestAdmin() } }
        btnStart = btn().also { it.setOnClickListener { pickTime(true) } }
        btnEnd = btn().also { it.setOnClickListener { pickTime(false) } }
        btnToggle = btn().also { it.setOnClickListener { toggle() } }
        btn().apply {
            text = "ব্যাটারি অপটিমাইজেশন বন্ধ করুন (জরুরি)"
            setOnClickListener { ignoreBattery() }
        }

        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (Prefs.enabled(this)) startForegroundService(Intent(this, LockService::class.java))
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun locked(): Boolean {
        if (Prefs.inLockWindow(this)) {
            Toast.makeText(this, "লক সময়ে সেটিংস বদলানো যাবে না", Toast.LENGTH_LONG).show()
            return true
        }
        return false
    }

    private fun refresh() {
        val isAdmin = dpm.isAdminActive(admin)
        btnAdmin.text = if (isAdmin) "✅ অ্যাডমিন অনুমতি দেওয়া আছে" else "১) অ্যাডমিন অনুমতি দিন"
        btnAdmin.isEnabled = !isAdmin
        btnStart.text = "লক শুরু: ${Prefs.fmt(Prefs.start(this))}"
        btnEnd.text = "লক শেষ: ${Prefs.fmt(Prefs.end(this))}"
        btnToggle.text = if (Prefs.enabled(this)) "বন্ধ করুন" else "২) লক চালু করুন"
        status.text = when {
            !isAdmin -> "আগে অ্যাডমিন অনুমতি দিন।"
            Prefs.enabled(this) -> "চালু আছে। প্রতিদিন ${Prefs.fmt(Prefs.start(this))} থেকে ${Prefs.fmt(Prefs.end(this))} পর্যন্ত ফোন লক থাকবে।"
            else -> "বন্ধ আছে।"
        }
    }

    private fun requestAdmin() {
        startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "নির্ধারিত রাতের সময়ে ফোন লক করার জন্য এই অনুমতি দরকার।")
        })
    }

    private fun pickTime(isStart: Boolean) {
        if (locked()) return
        val cur = if (isStart) Prefs.start(this) else Prefs.end(this)
        TimePickerDialog(this, { _, h, m ->
            if (isStart) Prefs.setStart(this, h * 60 + m) else Prefs.setEnd(this, h * 60 + m)
            refresh()
        }, cur / 60, cur % 60, false).show()
    }

    private fun toggle() {
        if (locked()) return
        if (!dpm.isAdminActive(admin)) {
            Toast.makeText(this, "আগে অ্যাডমিন অনুমতি দিন", Toast.LENGTH_LONG).show()
            return
        }
        val on = !Prefs.enabled(this)
        Prefs.setEnabled(this, on)
        if (on) startForegroundService(Intent(this, LockService::class.java))
        else stopService(Intent(this, LockService::class.java))
        refresh()
    }

    private fun ignoreBattery() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            Toast.makeText(this, "আগে থেকেই বন্ধ করা আছে ✅", Toast.LENGTH_SHORT).show()
        } else {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        }
    }
}
