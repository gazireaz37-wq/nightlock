package com.reaz.nightlock

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val dayNames = arrayOf("রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার")

    private lateinit var root: LinearLayout
    private lateinit var current: LinearLayout
    private lateinit var heroStatus: TextView
    private lateinit var heroSub: TextView
    private lateinit var btnToggle: Button
    private lateinit var btnPending: Button
    private lateinit var btnAdmin: Button
    private lateinit var btnOverlay: Button
    private lateinit var btnUsage: Button
    private lateinit var btnPass: Button
    private lateinit var btnDays: Button
    private lateinit var btnStart: Button
    private lateinit var btnEnd: Button
    private lateinit var btnMsg: Button
    private lateinit var btnApps: Button
    private lateinit var btnStealth: Button
    private lateinit var btnJitter: Button
    private val modeBtns = arrayOfNulls<Button>(2)

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 30_000)
        }
    }

    private val admin by lazy { ComponentName(this, AdminReceiver::class.java) }
    private val dpm by lazy { getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager }

    // ---------- ডিজাইন সহায়ক ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: String, r: Int) = GradientDrawable().apply {
        setColor(Color.parseColor(color))
        cornerRadius = dp(r).toFloat()
    }

    private fun card(title: String?): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded("#1E293B", 20)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        root.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        if (title != null) {
            c.addView(TextView(this).apply {
                text = title
                textSize = 13f
                setTextColor(Color.parseColor("#94A3B8"))
            })
        }
        current = c
        return c
    }

    private fun btn(accent: Boolean = false, onClick: () -> Unit): Button = Button(this).apply {
        isAllCaps = false
        textSize = 15f
        setTextColor(Color.WHITE)
        background = rounded(if (accent) "#6366F1" else "#334155", 14)
        stateListAnimator = null
        gravity = Gravity.CENTER_VERTICAL or Gravity.START
        setPadding(dp(16), dp(12), dp(16), dp(12))
        setOnClickListener { onClick() }
        current.addView(this, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
    }

    private fun setOn(b: Button, on: Boolean) {
        b.isEnabled = on
        b.alpha = if (on) 1f else 0.5f
    }

    // ---------- তৈরি ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#0F172A")
        window.navigationBarColor = Color.parseColor("#0F172A")
        createChannels()

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(48), dp(16), dp(32))
            setBackgroundColor(Color.parseColor("#0F172A"))
        }

        // হিরো কার্ড
        card(null)
        current.addView(TextView(this).apply {
            text = "🌙 রাতের লক"
            textSize = 14f
            setTextColor(Color.parseColor("#94A3B8"))
        })
        heroStatus = TextView(this).apply {
            textSize = 28f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, 0)
        }
        current.addView(heroStatus)
        heroSub = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#CBD5E1"))
            setPadding(0, dp(4), 0, dp(8))
        }
        current.addView(heroSub)
        btnToggle = btn(true) { toggle() }
        btn { showStats() }.text = "📊 রাতের রেকর্ড"
        btnPending = btn { showPending() }

        // অনুমতি
        card("অনুমতি")
        btnAdmin = btn { requestAdmin() }
        btnOverlay = btn { requestOverlay() }
        btnUsage = btn { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        btn { ignoreBattery() }.text = "ব্যাটারি অপটিমাইজেশন বন্ধ করুন (জরুরি)"
        btn { hideNotification() }.text = "🔕 স্থায়ী নোটিফিকেশন বন্ধ করুন"

        // ঘুম মোড
        card("ঘুম মোড (রাতের লক)")
        btnPass = btn { guard { setPassword() } }
        btnDays = btn { pickDays() }
        btnStart = btn { pickTime(true) }
        btnEnd = btn { pickTime(false) }
        btn { pickDaySchedules() }.text = "দিনভেদে আলাদা সময়"
        btnMsg = btn { editMessage() }
        btnApps = btn { pickApps() }
        btnJitter = btn { jitterSettings() }
        btnStealth = btn { toggleStealth() }

        // অন্যান্য মোড
        card("অন্যান্য মোড")
        for (i in 0..1) {
            modeBtns[i] = btn { guard { showMode(i) } }
        }

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0F172A"))
            addView(root)
        })

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (Prefs.enabled(this)) startForegroundService(Intent(this, LockService::class.java))
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("nl", "রাতের লক", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel("nl_alert", "লকের সতর্কবার্তা", NotificationManager.IMPORTANCE_HIGH))
    }

    override fun onResume() {
        super.onResume()
        if (Prefs.applyPendingDisable(this)) stopService(Intent(this, LockService::class.java))
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun daysText(): String {
        val m = Prefs.days(this)
        if (m == 127) return "প্রতি রাত"
        if (m == 0) return "কোনো রাত নয়"
        return dayNames.indices.filter { (m and (1 shl it)) != 0 }
            .joinToString(", ") { dayNames[it].removeSuffix("বার") }
    }

    private fun refresh() {
        Prefs.applyPendingChanges(this)
        LockWidget.updateAll(this)
        val isAdmin = dpm.isAdminActive(admin)
        val overlay = Settings.canDrawOverlays(this)
        val usage = Perm.usageAccess(this)
        val enabled = Prefs.enabled(this)
        val pending = Prefs.disableMinutesLeft(this)

        heroStatus.text = Prefs.shortStatus(this)
        heroSub.text = when {
            !isAdmin -> "আগে অ্যাডমিন অনুমতি দিন"
            !enabled -> "লক বন্ধ আছে"
            pending != null -> "⏳ লক বন্ধ হবে ${Prefs.humanDuration(pending)} পরে\nটানা পরিষ্কার রাত: ${Prefs.streak(this)}"
            else -> "${daysText()} রাতে লক • টানা পরিষ্কার রাত: ${Prefs.streak(this)}"
        }
        btnToggle.text = when {
            !enabled -> "▶ লক চালু করুন"
            pending != null -> "↩ বন্ধ করার অনুরোধ বাতিল করুন"
            else -> "⏹ লক বন্ধ করার অনুরোধ (২৪ ঘণ্টা পরে)"
        }

        btnAdmin.text = if (isAdmin) "✅ অ্যাডমিন অনুমতি আছে" else "১) অ্যাডমিন অনুমতি দিন"
        setOn(btnAdmin, !isAdmin)
        btnOverlay.text = if (overlay) "✅ লক পর্দার অনুমতি আছে" else "২) অন্য অ্যাপের উপরে দেখানোর অনুমতি দিন"
        setOn(btnOverlay, !overlay)
        btnUsage.text = if (usage) "✅ ইউসেজ অ্যাক্সেস আছে" else "অনুমোদিত অ্যাপের জন্য ইউসেজ অ্যাক্সেস দিন"
        setOn(btnUsage, !usage)

        btnPass.text = if (Prefs.hasPass(this)) "পাসওয়ার্ড বদলান" else "৩) পাসওয়ার্ড সেট করুন"
        btnDays.text = "যেসব রাতে লক: ${daysText()}"
        btnStart.text = "ডিফল্ট লক শুরু: ${Prefs.fmt(Prefs.start(this))}"
        btnEnd.text = "ডিফল্ট লক শেষ: ${Prefs.fmt(Prefs.end(this))}"
        btnMsg.text = "লক পর্দার বার্তা: ${Prefs.msg(this)}"
        btnApps.text = "লক সময়ে অনুমোদিত অ্যাপ (${Prefs.allowed(this).size}টি)"
        btnJitter.text = "লক শুরুর এলোমেলো দেরি: ${Prefs.jitterMax(this)} মিনিট"
        btnStealth.text = if (Prefs.stealth(this)) "🕶 গোপন মোড: চালু" else "🕶 গোপন মোড: বন্ধ"

        val pc = Prefs.pendingCount(this)
        btnPending.visibility = if (pc > 0) View.VISIBLE else View.GONE
        btnPending.text = "⏳ অপেক্ষমাণ পরিবর্তন ($pc)"
        if (Prefs.takePendingNotice()) toast("⏳ লক দুর্বল করে এমন বদল ২৪ ঘণ্টা পরে কার্যকর হবে")

        for (i in 0..1) {
            val state = if (Prefs.modeOn(this, i)) "চালু" else "বন্ধ"
            modeBtns[i]?.text =
                "${Prefs.MODE_ICONS[i]} ${Prefs.modeName(i)} মোড: $state\n${Prefs.fmt(Prefs.modeStart(this, i))} – ${Prefs.fmt(Prefs.modeEnd(this, i))}"
        }
    }

    // ---------- পাসওয়ার্ড ----------
    // লক চালু থাকলে যেকোনো বদল করতে পাসওয়ার্ড লাগবে
    private fun guard(action: () -> Unit) {
        if (!Prefs.enabled(this) || !Prefs.hasPass(this)) { action(); return }
        val et = pwField("পাসওয়ার্ড")
        AlertDialog.Builder(this)
            .setTitle("পাসওয়ার্ড দিন")
            .setView(wrap(et))
            .setPositiveButton("ঠিক আছে") { _, _ ->
                if (Prefs.checkPass(this, et.text.toString())) action() else toast("ভুল পাসওয়ার্ড")
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun pwField(h: String) = EditText(this).apply {
        hint = h
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    private fun numField(h: String, v: Int) = EditText(this).apply {
        hint = h
        inputType = InputType.TYPE_CLASS_NUMBER
        setText(v.toString())
    }

    private fun wrap(vararg v: EditText): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(48, 16, 48, 0)
        v.forEach { addView(it) }
    }

    private fun setPassword() {
        val a = pwField("নতুন পাসওয়ার্ড (কমপক্ষে ৪ অক্ষর)")
        val b = pwField("আবার লিখুন")
        AlertDialog.Builder(this)
            .setTitle("পাসওয়ার্ড সেট করুন")
            .setView(wrap(a, b))
            .setPositiveButton("সেভ") { _, _ ->
                val p = a.text.toString()
                when {
                    p.length < 4 -> toast("কমপক্ষে ৪ অক্ষর দিন")
                    p != b.text.toString() -> toast("দুটো মিলছে না")
                    else -> { Prefs.setPass(this, p); refresh() }
                }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    // ---------- অনুমতি ----------
    private fun requestAdmin() {
        startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "নির্ধারিত সময়ে ফোন লক করার জন্য এই অনুমতি দরকার।")
        })
    }

    private fun requestOverlay() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun ignoreBattery() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            toast("আগে থেকেই বন্ধ করা আছে ✅")
        } else {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        }
    }

    private fun hideNotification() {
        AlertDialog.Builder(this)
            .setTitle("স্থায়ী নোটিফিকেশন বন্ধ")
            .setMessage(
                "পরের পর্দায় \"রাতের লক\" চ্যানেলটা বন্ধ করে দিন। নোটিফিকেশন চলে যাবে কিন্তু লক কাজ করবে।\n\n" +
                "এরপর অ্যাপ খুলতে হোম স্ক্রিন উইজেট বা Quick Settings টাইল ব্যবহার করবেন, তাই এগুলো আগে যোগ করে নিন।"
            )
            .setPositiveButton("চালিয়ে যান") { _, _ ->
                startActivity(
                    Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                        .putExtra(Settings.EXTRA_CHANNEL_ID, "nl")
                )
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    // ---------- চালু/বন্ধ (২৪ ঘণ্টা অপেক্ষা) ----------
    private fun toggle() {
        if (!dpm.isAdminActive(admin)) { toast("আগে অ্যাডমিন অনুমতি দিন"); return }
        if (!Prefs.enabled(this)) {
            if (!Prefs.hasPass(this)) { toast("আগে পাসওয়ার্ড সেট করুন"); return }
            Prefs.setEnabled(this, true)
            Prefs.cancelDisable(this)
            startForegroundService(Intent(this, LockService::class.java))
            refresh()
        } else if (Prefs.disableMinutesLeft(this) != null) {
            Prefs.cancelDisable(this)
            toast("বন্ধ করার অনুরোধ বাতিল হয়েছে")
            refresh()
        } else {
            guard {
                AlertDialog.Builder(this)
                    .setTitle("লক বন্ধ করার অনুরোধ")
                    .setMessage("লক এখনই বন্ধ হবে না, ২৪ ঘণ্টা পরে বন্ধ হবে। এর মধ্যে চাইলে অনুরোধ বাতিল করতে পারবেন।")
                    .setPositiveButton("অনুরোধ করুন") { _, _ -> Prefs.requestDisable(this); refresh() }
                    .setNegativeButton("বাতিল", null)
                    .show()
            }
        }
    }

    // ---------- দিন ও সময় ----------
    private fun daysDialog(title: String, mask: Int, onSave: (Int) -> Unit) {
        val checked = BooleanArray(7) { (mask and (1 shl it)) != 0 }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMultiChoiceItems(dayNames, checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("সেভ") { _, _ ->
                var m = 0
                checked.forEachIndexed { i, v -> if (v) m = m or (1 shl i) }
                onSave(m)
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun timeDialog(cur: Int, title: String?, onPick: (Int) -> Unit) {
        val d = TimePickerDialog(this, { _, h, m -> onPick(h * 60 + m) }, cur / 60, cur % 60, false)
        if (title != null) d.setTitle(title)
        d.show()
    }

    private fun pickDays() = guard {
        daysDialog("যেসব রাতে লক (সন্ধ্যার দিন)", Prefs.days(this)) { Prefs.setDays(this, it); refresh() }
    }

    private fun pickTime(isStart: Boolean) = guard {
        val cur = if (isStart) Prefs.start(this) else Prefs.end(this)
        timeDialog(cur, null) {
            if (isStart) Prefs.setStart(this, it) else Prefs.setEnd(this, it)
            refresh()
        }
    }

    private fun pickDaySchedules() = guard { showDayList() }

    private fun showDayList() {
        val items = Array(7) { i ->
            "${dayNames[i]}: ${Prefs.fmt(Prefs.startFor(this, i))} – ${Prefs.fmt(Prefs.endFor(this, i))}"
        }
        AlertDialog.Builder(this)
            .setTitle("দিনভেদে সময় (দিন ট্যাপ করুন)")
            .setItems(items) { _, i -> editDay(i) }
            .setNeutralButton("সব রিসেট") { _, _ -> Prefs.clearDaySchedules(this); refresh() }
            .setNegativeButton("বন্ধ", null)
            .show()
    }

    private fun editDay(i: Int) {
        timeDialog(Prefs.startFor(this, i), "${dayNames[i]} — লক শুরু") { s ->
            timeDialog(Prefs.endFor(this, i), "${dayNames[i]} — লক শেষ") { e ->
                Prefs.setDaySchedule(this, i, s, e)
                refresh()
                showDayList()
            }
        }
    }

    // ---------- বার্তা ----------
    private fun editMessage() = guard {
        val et = EditText(this)
        et.setText(Prefs.msg(this))
        et.hint = "লক পর্দার বার্তা"
        AlertDialog.Builder(this)
            .setTitle("লক পর্দার বার্তা")
            .setView(wrap(et))
            .setPositiveButton("সেভ") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) { Prefs.setMsg(this, t); refresh() }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    // ---------- অনুমোদিত অ্যাপ ----------
    private fun pickApps() = guard { appPicker(-1) }

    @Suppress("DEPRECATION")
    private fun appPicker(mode: Int) {
        if (!Perm.usageAccess(this)) {
            toast("আগে ইউসেজ অ্যাক্সেস অনুমতি দিন")
            return
        }
        val pm = packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val cur = if (mode < 0) Prefs.allowed(this) else Prefs.modeAllowed(this, mode)
        val checked = BooleanArray(apps.size) { apps[it].first in cur }
        AlertDialog.Builder(this)
            .setTitle("লক সময়ে যেসব অ্যাপ চলবে")
            .setMultiChoiceItems(apps.map { it.second }.toTypedArray(), checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("সেভ") { _, _ ->
                val set = HashSet<String>()
                checked.forEachIndexed { i, v -> if (v) set.add(apps[i].first) }
                if (mode < 0) Prefs.setAllowed(this, set) else Prefs.setModeAllowed(this, mode, set)
                refresh()
                if (mode >= 0) showMode(mode)
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    // ---------- অন্যান্য মোড ----------
    private fun showMode(i: Int) {
        val on = Prefs.modeOn(this, i)
        val items = arrayOf(
            if (on) "বন্ধ করুন" else "চালু করুন",
            "দিন বাছাই",
            "শুরুর সময়",
            "শেষের সময়",
            "অনুমোদিত অ্যাপ",
            "লক পর্দার বার্তা"
        )
        AlertDialog.Builder(this)
            .setTitle("${Prefs.MODE_ICONS[i]} ${Prefs.modeName(i)} মোড")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> { Prefs.setModeOn(this, i, !on); refresh(); showMode(i) }
                    1 -> daysDialog("যেসব দিনে লক", Prefs.modeDays(this, i)) {
                        Prefs.setModeDays(this, i, it); refresh(); showMode(i)
                    }
                    2 -> timeDialog(Prefs.modeStart(this, i), "শুরুর সময়") {
                        Prefs.setModeStart(this, i, it); refresh(); showMode(i)
                    }
                    3 -> timeDialog(Prefs.modeEnd(this, i), "শেষের সময়") {
                        Prefs.setModeEnd(this, i, it); refresh(); showMode(i)
                    }
                    4 -> appPicker(i)
                    5 -> editModeMsg(i)
                }
            }
            .setNegativeButton("বন্ধ", null)
            .show()
    }

    private fun editModeMsg(i: Int) {
        val et = EditText(this)
        et.setText(Prefs.modeMsg(this, i))
        et.hint = "লক পর্দার বার্তা"
        AlertDialog.Builder(this)
            .setTitle("লক পর্দার বার্তা")
            .setView(wrap(et))
            .setPositiveButton("সেভ") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotEmpty()) Prefs.setModeMsg(this, i, t)
                refresh()
                showMode(i)
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    // ---------- গোপন মোড ----------
    private fun jitterSettings() = guard {
        val a = numField("সর্বোচ্চ কত মিনিট দেরি (০ = ঠিক সময়ে, সর্বোচ্চ ৬০)", Prefs.jitterMax(this))
        AlertDialog.Builder(this)
            .setTitle("এলোমেলো দেরি")
            .setMessage("প্রতি রাতে লক শুরুর সময়ের পরে এই সীমার মধ্যে যেকোনো মিনিটে হঠাৎ লক হবে, কখন হবে আপনি আগে জানবেন না।")
            .setView(wrap(a))
            .setPositiveButton("সেভ") { _, _ ->
                val x = a.text.toString().toIntOrNull()
                if (x == null || x !in 0..60) toast("০ থেকে ৬০ এর মধ্যে দিন")
                else { Prefs.setJitter(this, x); refresh() }
            }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun toggleStealth() = guard {
        if (Prefs.stealth(this)) {
            Prefs.setStealth(this, false)
            Stealth.setIconVisible(this, true)
            toast("গোপন মোড বন্ধ, আইকন ফিরে এসেছে")
            refresh()
        } else {
            AlertDialog.Builder(this)
                .setTitle("গোপন মোড চালু করবেন?")
                .setMessage(
                    "• অ্যাপের আইকন লুকিয়ে যাবে\n" +
                    "• লকের আগে কোনো সতর্কবার্তা আসবে না\n" +
                    "• নোটিফিকেশন সাধারণ নামে ও লক পর্দায় লুকানো থাকবে\n\n" +
                    "অ্যাপ খুলতে হোম স্ক্রিন উইজেট, Quick Settings টাইল বা নোটিফিকেশনের \"ব্যাকগ্রাউন্ড সার্ভিস\" লেখায় ট্যাপ করুন। " +
                    "আইকন ফিরিয়ে আনার আরেক উপায়: APK আবার ইনস্টল করা।"
                )
                .setPositiveButton("চালু করুন") { _, _ ->
                    Prefs.setStealth(this, true)
                    Stealth.setIconVisible(this, false)
                    refresh()
                }
                .setNegativeButton("বাতিল", null)
                .show()
        }
    }

    // ---------- অপেক্ষমাণ পরিবর্তন ----------
    private fun showPending() {
        val lines = Prefs.pendingLines(this)
        AlertDialog.Builder(this)
            .setTitle("২৪ ঘণ্টা পরে কার্যকর হবে")
            .setMessage(if (lines.isEmpty()) "কোনো অপেক্ষমাণ পরিবর্তন নেই" else lines.joinToString("\n\n"))
            .setPositiveButton("ঠিক আছে", null)
            .setNeutralButton("সব বাতিল") { _, _ -> Prefs.cancelPendingChanges(this); refresh() }
            .show()
    }

    // ---------- রেকর্ড ----------
    private fun showStats() {
        val sb = StringBuilder()
        sb.append("টানা পরিষ্কার রাত (ফোন খোলার চেষ্টা ছাড়া): ${Prefs.streak(this)}\n\nশেষ ৭ রাত:\n")
        val l = Prefs.recentNights(this)
        if (l.isEmpty()) sb.append("এখনো কোনো রেকর্ড নেই\n")
        else l.forEach { sb.append("${it.key}: আনলকের চেষ্টা ${it.att}\n") }
        AlertDialog.Builder(this)
            .setTitle("রেকর্ড")
            .setMessage(sb.toString())
            .setPositiveButton("ঠিক আছে", null)
            .show()
    }
}
