package com.reaz.nightlock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Prefs.enabled(context)) {
            context.startForegroundService(Intent(context, LockService::class.java))
        }
    }
}
