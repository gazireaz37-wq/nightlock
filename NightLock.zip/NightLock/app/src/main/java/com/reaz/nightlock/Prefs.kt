package com.reaz.nightlock

import android.content.Context
import java.util.Calendar

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    // মিনিট হিসেবে (রাত ১২:৩০ = 30, সকাল ৬:০০ = 360)
    fun start(c: Context) = sp(c).getInt("start", 30)
    fun end(c: Context) = sp(c).getInt("end", 360)
    fun setStart(c: Context, v: Int) = sp(c).edit().putInt("start", v).apply()
    fun setEnd(c: Context, v: Int) = sp(c).edit().putInt("end", v).apply()

    fun inLockWindow(c: Context): Boolean {
        if (!enabled(c)) return false
        val now = Calendar.getInstance()
        val m = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val s = start(c)
        val e = end(c)
        return if (s <= e) m in s until e else (m >= s || m < e)
    }

    fun fmt(min: Int): String {
        val h24 = min / 60
        val m = min % 60
        val ampm = if (h24 < 12) "AM" else "PM"
        val h = if (h24 % 12 == 0) 12 else h24 % 12
        return "%d:%02d %s".format(h, m, ampm)
    }
}
