package com.reaz.nightlock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // অ্যাপ আপডেট/পুনরায় ইনস্টল হলে আইকন ফিরে আসে (বের হওয়ার পথ)
        if (intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            Prefs.setStealth(context, false)
            Stealth.setIconVisible(context, true)
        }
        Prefs.applyPendingDisable(context)
        Prefs.applyPendingChanges(context)
        if (Prefs.enabled(context)) {
            context.startForegroundService(Intent(context, LockService::class.java))
        }
    }
}
