package com.reaz.nightlock

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.admin.DevicePolicyManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings

class LockService : Service() {

    private val handler = Handler(Looper.getMainLooper())

    // অনুমোদিত অ্যাপ ব্যবহারের সেশন
    private var watchPkg: String? = null
    private var lastFg: String? = null

    private val watcher = object : Runnable {
        override fun run() {
            val p = watchPkg ?: return
            if (!Prefs.shouldLock(this@LockService)) { watchPkg = null; return }
            val fg = foregroundPackage()
            if (fg != null) lastFg = fg
            val cur = lastFg
            if (cur != null && cur != p && cur != packageName && cur != "com.android.systemui") {
                watchPkg = null
                lockNow(this@LockService)
                return
            }
            handler.postDelayed(this, 1000)
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_TIME_TICK -> {
                    if (Prefs.applyPendingDisable(c)) {
                        LockWidget.updateAll(c)
                        stopSelf()
                        return
                    }
                    Prefs.applyPendingChanges(c)
                    refreshNotification()
                    LockWidget.updateAll(c)
                    if (Prefs.inLockWindow(c)) Prefs.touchNight(c)
                    val r = Prefs.minutesToLock(c)
                    if (r != null && !Prefs.stealth(c) && (r == 15 || r == 10 || r == 5 || r == 1)) alert(r)
                    if (watchPkg == null && Prefs.shouldLock(c)) lockNow(c)
                }
                Intent.ACTION_SCREEN_ON -> {
                    if (watchPkg == null && Prefs.shouldLock(c)) lockNow(c)
                }
                Intent.ACTION_SCREEN_OFF -> {
                    watchPkg = null
                    handler.removeCallbacks(watcher)
                }
                Intent.ACTION_USER_PRESENT -> {
                    if (Prefs.shouldLock(c)) {
                        if (Prefs.inLockWindow(c)) Prefs.addAttempt(c)
                        if (watchPkg == null) showLockScreen(c)
                    }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("nl", "রাতের লক", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel("nl_alert", "লকের সতর্কবার্তা", NotificationManager.IMPORTANCE_HIGH))
        startForeground(1, ongoing("রাতের লক চালু আছে"))

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(Intent.ACTION_TIME_TICK)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val w = intent?.getStringExtra("watch")
        if (w != null) {
            beginWatch(w)
            return START_STICKY
        }
        refreshNotification()
        if (watchPkg == null && Prefs.shouldLock(this)) lockNow(this)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(watcher)
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun beginWatch(pkg: String) {
        if (!Perm.usageAccess(this)) return
        watchPkg = pkg
        lastFg = pkg
        handler.removeCallbacks(watcher)
        handler.postDelayed(watcher, 1500)
    }

    @Suppress("DEPRECATION")
    private fun foregroundPackage(): String? {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = usm.queryEvents(now - 10_000, now)
        val e = UsageEvents.Event()
        var pkg: String? = null
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) pkg = e.packageName
        }
        return pkg
    }

    private fun ongoing(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stealth = Prefs.stealth(this)
        return Notification.Builder(this, "nl")
            .setContentTitle(if (stealth) "ব্যাকগ্রাউন্ড সার্ভিস" else "রাতের লক")
            .setContentText(if (stealth) "চলছে" else text)
            .setSmallIcon(R.drawable.ic_blank)
            .setShowWhen(false)
            .setVisibility(Notification.VISIBILITY_SECRET)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun refreshNotification() {
        val r = Prefs.minutesToLock(this)
        val text = when {
            Prefs.shouldLock(this) -> "এখন লক সময়"
            r != null -> "ফোন $r মিনিট পরে লক হবে"
            else -> "নির্ধারিত রাতে লক হবে"
        }
        getSystemService(NotificationManager::class.java).notify(1, ongoing(text))
    }

    private fun alert(r: Int) {
        val n = Notification.Builder(this, "nl_alert")
            .setContentTitle("⏰ ফোন $r মিনিট পরে লক হবে")
            .setContentText("জরুরি কাজ এখনই শেষ করে নিন")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(2, n)
    }

    private fun showLockScreen(c: Context) {
        if (Settings.canDrawOverlays(c)) {
            c.startActivity(
                Intent(c, LockActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
            // অ্যাক্টিভিটি না খুললে সরাসরি লক
            handler.postDelayed({
                if (!LockActivity.shown && watchPkg == null && Prefs.shouldLock(c)) lockNow(c)
            }, 1500)
        } else {
            lockNow(c)
        }
    }

    companion object {
        fun lockNow(c: Context) {
            val dpm = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val admin = ComponentName(c, AdminReceiver::class.java)
            if (dpm.isAdminActive(admin)) dpm.lockNow()
        }
    }
}
